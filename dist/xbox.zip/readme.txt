You need HQ Https Proxies to work good on multi-threaded,
Otherwise there will be errors multi-threading.

To start the tool first, edit the settings.json file and put your account email and password.
Put the name of proxy file in the same directory, or put 'false' for no proxies.

Proxy file should be a txt list of https proxies seperated by new lines.

For anything else:
Contact me on discord dexy#7742